// OCEAN service worker.
// Page: network first (a new deploy shows on the next open), cached copy when
// offline. Icons and manifest: stale-while-revalidate. Forecast APIs are not
// cached here; the app keeps its last forecast itself and labels its age.
const CACHE='ocean-v28';
const SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('ocean-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
 const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==location.origin)return;
 if(r.mode==='navigate'){
  e.respondWith(fetch(r).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put('index.html',copy));return res;})
   .catch(()=>caches.match('index.html').then(m=>m||caches.match('./'))));
  return;
 }
 e.respondWith(caches.open(CACHE).then(async c=>{
  const hit=await c.match(r,{ignoreSearch:true});
  const net=fetch(r).then(res=>{if(res.ok)c.put(r,res.clone());return res;}).catch(()=>hit);
  if(hit){e.waitUntil(net);return hit;}
  return net;
 }));
});
